import expr.Expr;
import expr.Factor;
import expr.Number;
import expr.Pow;
import expr.Term;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parser {
    private final Lexer lexer;
    private final Pattern numberPattern = Pattern.compile("\\d+");

    public Parser(Lexer lexer) {
        this.lexer = lexer;
    }

    public Expr parseExpr() {
        skipBlank();
        BigInteger tsign = toSign(lexer.peek());
        if (isAddOrSub(lexer.peek())) {
            lexer.next();
        }
        skipBlank();
        Expr expr = new Expr();
        expr.addTerm(parseTerm(tsign));
        skipBlank();
        while (isAddOrSub(lexer.peek())) {
            tsign = toSign(lexer.peek());
            lexer.next();
            expr.addTerm(parseTerm(tsign));
            skipBlank();
        }
        return expr;
    }

    public Term parseTerm(BigInteger tsign) {
        skipBlank();
        final BigInteger theSign = toSign(lexer.peek()).multiply(tsign);
        if (isAddOrSub(lexer.peek())) {
            lexer.next();
        }
        skipBlank();
        Term term = new Term();
        term.addFactor(parseFactor());
        skipBlank();
        while (lexer.peek().equals("*")) {
            lexer.next();
            skipBlank();
            term.addFactor(parseFactor());
            skipBlank();
        }
        term.setSign(theSign);
        return term;
    }

    public Factor parseFactor() {
        skipBlank();
        if (lexer.peek().equals("(")) {
            lexer.next();
            Expr expr = parseExpr();
            if (!lexer.peek().equals(")")) {
                lexer.exitIt();
            } else {
                lexer.next();
                skipBlank();
                if (lexer.peek().equals("**")) {
                    lexer.next();
                    skipBlank();
                    BigInteger exponent = parseNonNegativeNumber();
                    expr.setExponent(exponent);
                    return expr;
                }
                return expr;
            }
        } else {
            String s = lexer.peek();
            if (isAddOrSub(s)) {
                lexer.next();
                BigInteger num = parseNonNegativeNumber();
                skipBlank();
                return new Number(num,toSign(s));
            } else if (s.equals("x")) {
                lexer.next();
                skipBlank();
                if (!lexer.peek().equals("**")) {
                    return new Pow(BigInteger.ONE);
                } else {
                    lexer.next();
                    skipBlank();
                    BigInteger exponent = parseNonNegativeNumber();
                    skipBlank();
                    return new Pow(exponent);
                }
            } else if (isNumber(s)) {
                lexer.next();
                skipBlank();
                return new Number(new BigInteger(s),BigInteger.ONE);
            } else {
                lexer.exitIt();
            }
        }
        return null;
    }

    public boolean isAddOrSub(String s) {
        return s.equals("+") || s.equals("-");
    }

    public BigInteger toSign(String s) {
        if (s.equals("-")) {
            return BigInteger.valueOf(-1);
        } else {
            return BigInteger.ONE;
        }
    }

    public boolean isNumber(String s) {
        Matcher matcher = numberPattern.matcher(s);
        //System.out.println(matcher.matches());
        return matcher.matches();
    }

    public void skipBlank() {
        if (lexer.peek().equals(" ")) {
            lexer.next();
        }
    }

    public BigInteger parseNonNegativeNumber() {
        if (lexer.peek().equals("+")) {
            lexer.next();
            BigInteger number = new BigInteger(lexer.peek());
            lexer.next();
            return number;
        } else {
            BigInteger number = new BigInteger(lexer.peek());
            lexer.next();
            return number;
        }
    }

}
