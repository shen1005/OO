package expr;

import java.math.BigInteger;
import java.util.ArrayList;

public class Term {
    private ArrayList<Factor> factors;
    private BigInteger sign;
    private BigInteger coefficient;
    private BigInteger exponent;

    public Term(BigInteger sign, ArrayList<Factor> factors) {
        this.sign = sign;
        this.factors = factors;
    }

    public Term(BigInteger exponent,BigInteger coefficient) {
        this.sign = BigInteger.valueOf(coefficient.signum());
        this.factors = new ArrayList<>();
        Number number = new Number(coefficient.abs(),BigInteger.ONE);
        Pow pow = new Pow(exponent);
        factors.add(number);
        factors.add(pow);
    }

    public Term() {
        this.sign = BigInteger.ONE;
        this.factors = new ArrayList<>();
        this.coefficient = BigInteger.ONE;
        this.exponent = BigInteger.ZERO;
    }

    public void addFactor(Factor factor) {
        this.factors.add(factor);
    }

    public ArrayList<Factor> getFactors() {
        return this.factors;
    }

    public BigInteger getExponent() {
        return exponent;
    }

    public BigInteger getCoefficient() {
        return coefficient;
    }

    public BigInteger getSign() {
        return sign;
    }

    public void setSign(BigInteger sign) {
        this.sign = sign;
    }

    public Term expand() {
        ArrayList<Factor> notExFactors = new ArrayList<>();
        for (Factor factor : factors) {
            if (!(factor instanceof Expr)) {
                notExFactors.add(factor);
            }
        }
        Term temp = new Term(this.sign, notExFactors);
        ArrayList<Term> tempTerms = new ArrayList<>();
        tempTerms.add(temp);
        Expr ans = new Expr(tempTerms);
        for (Factor factor : factors) {
            int i = 0;
            if (factor instanceof Expr) {
                while (i < ((Expr) factor).getExponent().intValue()) {
                    ans = ans.mul(((Expr) factor).expand());//有幂次的重复乘,注意要先展开再相乘
                    i++;
                }
            }
            if (i == 0 && notExFactors.size() == 0) {
                Number number = new Number(BigInteger.ONE, BigInteger.ONE);
                ArrayList<Factor> tempFac2 = new ArrayList<>();
                tempFac2.add(number);
                Term tempTerm2 = new Term(this.sign, tempFac2);
                ArrayList<Term> tempTerms2 = new ArrayList<>();
                tempTerms2.add(tempTerm2);
                ans = new Expr(tempTerms2);
            }
        }
        ArrayList<Factor> newFactors = new ArrayList<>();
        newFactors.add(ans);
        return new Term(BigInteger.ONE, newFactors);
    }

    public Term mul(Term other) {
        ArrayList<Factor> newFactors = new ArrayList<>();
        newFactors.addAll(this.factors);
        newFactors.addAll(other.factors);
        return new Term(this.getSign().multiply(other.getSign()), newFactors).expand();
    }

    public String toString() {
        this.simplify();
        StringBuilder sb = new StringBuilder();
        if (sign.equals(BigInteger.valueOf(-1))) {
            sb.append("-");
        } else {
            sb.append("+");
        }

        return sb + partToString(coefficient, exponent);
    }

    public String partToString(BigInteger coefficient, BigInteger exponent) {
        StringBuilder sb = new StringBuilder();
        if (coefficient.equals(BigInteger.ZERO)) {
            return "0";
        }
        if (!coefficient.equals(BigInteger.ONE)) {
            sb.append(coefficient);
            if (!exponent.equals(BigInteger.ZERO)) {
                sb.append("*");
            }
        }
        if (exponent.equals(BigInteger.ZERO)) {
            if (coefficient.equals(BigInteger.ONE)) {
                sb.append(1);
            }
        } else if (exponent.equals(BigInteger.ONE)) {
            sb.append("x");
        } else if (exponent.equals(BigInteger.valueOf(2))) {
            sb.append("x*x");
        } else {
            sb.append("x**").append(exponent);
        }
        return sb.toString();
    }

    public void addSign() {
        BigInteger ans = sign;
        int i = 0;
        while (i < factors.size()) {
            Number temp;
            if (factors.get(i) instanceof Number) {
                temp = new Number(((Number)factors.get(i)).getNum(),BigInteger.ONE);
                ans = ans.multiply(((Number)factors.get(i)).getSign());
                factors.set(i,temp);
            }
            i++;
        }
        this.setSign(ans);
    }

    public void simplify() {
        //System.out.println("factors.size() = " + factors.size());
        addSign();//符号统一

        ArrayList<Factor> newFactors = new ArrayList<>();
        BigInteger coef = BigInteger.ONE;
        for (Factor factor : factors) {
            if (factor instanceof Number) {
                coef = coef.multiply(((Number) factor).getNum());
            }
        }
        newFactors.add(new Number(coef, BigInteger.ONE));

        BigInteger expon = BigInteger.ZERO;
        for (Factor factor : factors) {
            if (factor instanceof Pow) {
                expon = expon.add(((Pow) factor).getExponent());
            }
        }
        newFactors.add(new Pow(expon));
        this.factors = newFactors;
        this.coefficient = coef;
        this.exponent = expon;
        //System.out.println("coefficient = " + coef);
        //System.out.println("exponent = " + expon);
    }

}
