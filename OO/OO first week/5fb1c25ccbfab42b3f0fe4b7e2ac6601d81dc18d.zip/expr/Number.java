package expr;

import java.math.BigInteger;

public class Number implements Factor {
    private final BigInteger num;
    private BigInteger sign;

    public Number(BigInteger num, BigInteger sign) {
        this.num = num;
        this.sign = sign;
    }

    public BigInteger getSign() {
        return this.sign;
    }

    public BigInteger getNum() {
        return this.num;
    }

    public String toString() {
        return this.num.toString();
    }

}
