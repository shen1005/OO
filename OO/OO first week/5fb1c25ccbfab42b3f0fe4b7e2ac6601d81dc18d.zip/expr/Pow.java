package expr;

import java.math.BigInteger;

public class Pow implements Factor {
    private BigInteger exponent;

    public Pow(BigInteger exponent) {
        this.exponent = exponent;
    }

    public BigInteger getExponent() {
        return this.exponent;
    }

    public String toString() {
        if (exponent.equals(BigInteger.ZERO)) {
            return "1";
        } else if (exponent.equals(BigInteger.ONE)) {
            return "x";
        } else {
            return "x" + "**" + exponent;
        }
    }
}
