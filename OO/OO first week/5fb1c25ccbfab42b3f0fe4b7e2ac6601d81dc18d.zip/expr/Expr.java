package expr;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;

public class Expr implements Factor {
    private ArrayList<Term> terms;
    private BigInteger exponent = BigInteger.ONE;

    public Expr() {
        this.terms = new ArrayList<>();
    }

    public Expr(ArrayList<Term> terms) {
        this.terms = terms;
    }

    public void addTerm(Term term) {
        this.terms.add(term);
    }

    public ArrayList<Term> getTerms() {
        return terms;
    }

    public void setExponent(BigInteger exponent) {
        this.exponent = exponent;
    }

    public BigInteger getExponent() {
        return exponent;
    }

    public Expr expand() {
        ArrayList<Term> newTerms = new ArrayList<>();
        for (Term term : terms) {
            newTerms.addAll(((Expr) term.expand().getFactors().get(0)).getTerms());
        }
        return new Expr(newTerms);
    }

    public Expr mul(Expr other) {
        ArrayList<Term> newTerms = new ArrayList<>();
        for (Term term1 : this.getTerms()) {
            for (Term term2 : other.getTerms()) {
                newTerms.addAll(((Expr) term1.mul(term2).getFactors().get(0)).getTerms());
            }
        }
        return new Expr(newTerms);
    }

    public Expr addSimplify() {
        HashMap<BigInteger, BigInteger> hashTerms = new HashMap<>();// exponent && coefficient
        for (Term term : terms) {
            term.simplify();
            if (hashTerms.containsKey(term.getExponent())) {
                BigInteger temp = term.getCoefficient().multiply(term.getSign());
                hashTerms.put(term.getExponent(), hashTerms.get(term.getExponent()).add(temp));
            } else {
                hashTerms.put(term.getExponent(), term.getCoefficient().multiply(term.getSign()));
            }
        }
        Expr ans = new Expr();
        for (BigInteger key : hashTerms.keySet()) {
            ans.addTerm(new Term(key, hashTerms.get(key)));
        }
        return ans;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        int i = 1;
        for (i = 0; i < terms.size(); i++) {
            if (terms.get(i).getSign().equals(BigInteger.ONE)) {
                sb.append(terms.get(i));
            }
        }
        for (i = 0; i < terms.size(); i++) {
            if (!terms.get(i).getSign().equals(BigInteger.ONE)) {
                sb.append(terms.get(i));
            }
        }
        if (exponent.equals(BigInteger.ZERO)) {
            return "1";
        } else if (exponent.equals(BigInteger.ONE)) {
            return deleteAdjust(sb.toString());
        } else {
            return deleteAdjust(sb.toString() + "**" + exponent.toString());
        }
    }

    public String deleteAdjust(String s) {
        if (s.length() >= 2) {
            //System.out.println("s = " + s);
            String s1 = s.replaceAll("\\+0", "");
            if (s1.equals("")) {
                return "0";
            }
            if (s1.charAt(0) == '+') {
                return s1.substring(1);
            } else {
                return s1;
            }
        } else {
            if (s.charAt(0) == '+') {
                return s.substring(1);
            } else {
                return s;
            }
        }
    }

}