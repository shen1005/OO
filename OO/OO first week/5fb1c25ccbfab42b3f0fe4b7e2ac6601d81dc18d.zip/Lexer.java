public class Lexer {
    private final String input;
    private int pos = 0;
    private String curToken;

    public void exitIt() {
        System.out.println("pos=" + pos);
        System.out.println("curToken is " + curToken);
        System.out.println("the wrong char is " + getChar(pos));
        System.out.println("WrongFormat when lexer");
        System.exit(0);
    }

    public Lexer(String input) {
        this.input = input;
        this.next();
    }

    private Character getChar(int pos) {
        return input.charAt(pos);
    }

    public int getPos() {
        return pos;
    }

    private boolean isBlank(Character c) {
        return " ".equals(String.valueOf(c)) || "\t".equals(String.valueOf(c));
    }

    private void skipBlank() {
        pos++;
        if (isBlank(getChar(pos))) {
            while (isBlank(getChar(pos))) {
                pos++;
            }
            curToken = " ";
        }
    }
    //首先pos++，此时如果C是空白符，则pos跳过直到input.charAt(pos)不为空白符

    private String getNumber() {
        //注意前导0
        StringBuilder sb = new StringBuilder();
        while (pos < input.length() && Character.isDigit(getChar(pos))) {
            sb.append(getChar(pos));
            ++pos;
        }
        return sb.toString();
    }

    public void next() {
        if (pos == input.length()) {
            return;
        }

        char c = getChar(pos);
        if (isBlank(c)) {
            curToken = " "; //如果只有一个空白符也需要返回" "
            skipBlank();
        } else if (Character.isDigit(c)) {
            curToken = getNumber();
        } else if (c == '*') {
            pos++;
            if (getChar(pos) == '*') {
                pos++;
                curToken = "**";
            } else {
                curToken = "*";
            }
        } else if ("+-()x".indexOf(c) != -1) {
            pos += 1;
            curToken = String.valueOf(c);
        } else {
            exitIt();
        }
    }

    public String peek() {
        return this.curToken;
    }

}