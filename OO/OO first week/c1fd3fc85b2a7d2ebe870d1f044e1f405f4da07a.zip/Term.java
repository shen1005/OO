import java.math.BigInteger;
import java.util.ArrayList;

public class Term implements Factor {
    private final ArrayList<Factor> factors;
    
    public String getOp() {
        return op;
    }
    
    private String op;
    
    public Term() {
        this.factors = new ArrayList<>();
    }
    
    public void addFactor(Factor factor) {
        this.factors.add(factor);
    }
    
    public void setOp(String op) {
        this.op = op;
    }
    
    public Polynomial makePoly() {
        Polynomial p1 = new Polynomial(0, new BigInteger("1"));
        for (Factor factor : factors) {
            Polynomial p2 = factor.makePoly();
            p1 = p1.mul(p2);
        }
        return p1;
    }
}
