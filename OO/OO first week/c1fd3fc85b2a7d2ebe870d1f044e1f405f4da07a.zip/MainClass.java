import com.oocourse.spec1.ExprInput;
import com.oocourse.spec1.ExprInputMode;

public class MainClass {
    public static void main(String[] args) {
        ExprInput scanner = new ExprInput(ExprInputMode.NormalMode);
        String input = scanner.readLine();
        Lexer lexer = new Lexer(input.replaceAll("[\\s]*",""));//去除所有空格
        Parser parser = new Parser(lexer);
        
        Expr expr = parser.parseExpr();
        Polynomial p = expr.makePoly();
        System.out.println(p);
    }
}


