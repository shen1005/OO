import java.math.BigInteger;

public class Number implements Factor {
    private final BigInteger num;
    
    public Number(BigInteger num) {
        this.num = num;
    }
    
    public Number(String str) {
        this.num = new BigInteger(str);
    }
    
    public BigInteger add(Number other) {
        return this.num.add(other.num);
    }
    
    public String toString() {
        return this.num.toString();
    }
    
    public Polynomial makePoly() {
        return new Polynomial(0, num);
    }
}