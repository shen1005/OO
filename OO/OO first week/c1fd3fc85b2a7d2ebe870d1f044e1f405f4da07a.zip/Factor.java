public interface Factor {
    Polynomial makePoly();
}
