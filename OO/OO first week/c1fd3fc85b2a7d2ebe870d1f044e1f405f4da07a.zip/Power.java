import java.math.BigInteger;

public class Power implements Factor {
    private final int index;
    
    public Power(int index) {
        this.index = index;
    }
    
    public Polynomial makePoly() {
        return new Polynomial(index, new BigInteger("1"));
    }
}
