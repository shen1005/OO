import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Polynomial {
    public HashMap<Integer, BigInteger> getPolynomial() {
        return polynomial;
    }
    
    private final HashMap<Integer, BigInteger> polynomial;
    
    public Polynomial(Integer index, BigInteger coefficient) {
        this.polynomial = new HashMap<>();
        this.polynomial.put(index, coefficient);
    }
    
    public Polynomial(HashMap<Integer, BigInteger> polynomial) {
        this.polynomial = polynomial;
    }
    
    public Polynomial add(Polynomial other) {
        HashMap<Integer, BigInteger> sbMap = new HashMap<>();
        Set<Integer> set = new HashSet<>();
        set.addAll(this.getPolynomial().keySet());
        set.addAll(other.getPolynomial().keySet());
        for (int i : set) {
            if (this.getPolynomial().containsKey(i) && other.getPolynomial().containsKey(i)) {
                sbMap.put(i, this.getPolynomial().get(i).add(other.getPolynomial().get(i)));
            } else if (this.getPolynomial().containsKey(i)) {
                sbMap.put(i, this.getPolynomial().get(i));
            } else if (other.getPolynomial().containsKey(i)) {
                sbMap.put(i, other.getPolynomial().get(i));
            }
        }
        return new Polynomial(sbMap);
    }
    
    public Polynomial sub(Polynomial other) {
        HashMap<Integer, BigInteger> sbMap = new HashMap<>();
        Set<Integer> set = new HashSet<>();
        set.addAll(this.getPolynomial().keySet());
        set.addAll(other.getPolynomial().keySet());
        for (int i : set) {
            if (this.getPolynomial().containsKey(i) && other.getPolynomial().containsKey(i)) {
                sbMap.put(i, this.getPolynomial().get(i).subtract(other.getPolynomial().get(i)));
            } else if (this.getPolynomial().containsKey(i)) {
                sbMap.put(i, this.getPolynomial().get(i));
            } else if (other.getPolynomial().containsKey(i)) {
                sbMap.put(i, other.getPolynomial().get(i).negate());
            }
        }
        return new Polynomial(sbMap);
    }
    
    public Polynomial mul(Polynomial other) {
        HashMap<Integer, BigInteger> sbMap = new HashMap<>();
        for (int index1 : this.getPolynomial().keySet()) {
            for (int index2 : other.getPolynomial().keySet()) {
                if (sbMap.containsKey(index1 + index2)) {
                    sbMap.put(index1 + index2, sbMap.get(index1 + index2)
                            .add(this.getPolynomial().get(index1)
                                    .multiply(other.getPolynomial().get(index2))));
                } else {
                    sbMap.put(index1 + index2, this.getPolynomial().get(index1)
                            .multiply(other.getPolynomial().get(index2)));
                }
            }
        }
        return new Polynomial(sbMap);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        HashMap<Integer, BigInteger> map = this.polynomial;
        int flag = -1;
        for (int index : map.keySet()) {
            if (map.get(index).compareTo(BigInteger.ZERO) > 0) {
                sb.append(toTerm(index, map));
                flag = index;
                break;
            }
        }
        for (int index : map.keySet()) {
            if (index != flag) {
                if (!sb.toString().isEmpty() && !map.get(index).equals(BigInteger.ZERO)) {
                    sb.append("+");
                }
                sb.append(toTerm(index, map));
            }
            
        }
        String s = sb.toString().replaceAll("[+][-]", "-");
        return s.isEmpty() ? "0" : s;
    }
    
    public static String toTerm(int index, HashMap<Integer, BigInteger> map) {
        StringBuilder sb = new StringBuilder();
        if (!map.get(index).equals(BigInteger.ZERO)) {
            if (map.get(index).equals(new BigInteger("1"))) {
                if (index == 0) {
                    sb.append(1);
                }
            } else if (map.get(index).equals(new BigInteger("-1"))) {
                if (index == 0) {
                    sb.append("-1");
                } else {
                    sb.append("-");
                }
            } else {
                sb.append(map.get(index));
                if (index != 0) {
                    sb.append("*");
                }
            }
            if (index == 1) {
                sb.append("x");
            } else if (index == 2) {
                sb.append("x*x");
            } else if (index > 2) {
                sb.append("x**").append(index);
            }
        }
        return sb.toString();
    }
}
