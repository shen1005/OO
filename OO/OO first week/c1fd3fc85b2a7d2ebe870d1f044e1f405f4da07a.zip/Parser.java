import java.math.BigInteger;

public class Parser {
    private final Lexer lexer;
    
    public Parser(Lexer lexer) {
        this.lexer = lexer;
    }
    
    public Expr parseExpr() {
        Expr expr = new Expr();//表达式首字符
        if (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            expr.addOp(lexer.peek());
            lexer.next();
        } else {
            expr.addOp("+");//缺省默认为正
        }
        expr.addTerm(parseTerm());
        //连接符
        while (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            expr.addOp(lexer.peek());
            lexer.next();
            expr.addTerm(parseTerm());
        }
        return expr;
    }
    
    public Term parseTerm() {
        Term term = new Term();//项首字符
        if (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            term.setOp(lexer.peek());
            lexer.next();
        } else {
            term.setOp("+");
        }
        term.addFactor(parseFactor(term));
        
        while (lexer.peek().equals("*")) {
            lexer.next();
            term.addFactor(parseFactor(term));
        }
        return term;
    }
    
    public Factor parseFactor(Term term) {
        if (lexer.peek().equals("(")) {
            lexer.next();
            Factor expr = parseExpr();//lexer.peek() == ')';
            lexer.next();//指向右括号后的字符
            if (!lexer.peek().isEmpty() && Character.isDigit(lexer.peek().charAt(0))) {
                int num = Integer.parseInt(lexer.peek());//指数
                lexer.next();//展开成多项
                if (num == 0) {
                    return new Number(BigInteger.ONE);//零次方等于1
                }
                for (int i = 0; i < num - 1; i++) {
                    term.addFactor(expr);
                }
            }
            return expr;
        } else if (lexer.peek().equals("x")) {
            lexer.next();//指向x后的字符
            if (!lexer.peek().isEmpty() && Character.isDigit(lexer.peek().charAt(0))) {
                int num = Integer.parseInt(lexer.peek());//指数
                lexer.next();
                return new Power(num);
            } else {
                return new Power(1);//缺省为1
            }
        } else if (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            String op = lexer.peek();
            lexer.next();//指向下一个数
            BigInteger num = new BigInteger(op + lexer.peek());//
            lexer.next();//下一个字符
            return new Number(num);
        } else {
            BigInteger num = new BigInteger(lexer.peek());//
            lexer.next();//下一个字符
            return new Number(num);
        }
    }
}
