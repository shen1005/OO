import java.math.BigInteger;
import java.util.ArrayList;

public class Expr implements Factor {
    private final ArrayList<Term> terms;
    private final ArrayList<String> ops;
    
    public Expr() {
        this.terms = new ArrayList<>();
        this.ops = new ArrayList<>();
    }
    
    public void addTerm(Term term) {
        this.terms.add(term);
    }
    
    public void addOp(String op) {
        this.ops.add(op);
    }
    
    public Polynomial makePoly() {
        int total = terms.size();
        Polynomial p1 = new Polynomial(0, new BigInteger("0"));
        for (int i = 0; i < total; i++) {
            Polynomial p2 = terms.get(i).makePoly();
            String op1 = ops.get(i);
            String op2 = terms.get(i).getOp();
            if (op1.equals(op2)) {
                p1 = p1.add(p2);
            } else {
                p1 = p1.sub(p2);
            }
        }
        return p1;
    }
}