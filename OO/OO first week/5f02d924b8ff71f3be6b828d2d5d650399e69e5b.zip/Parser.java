import expr.Expr;
import expr.ExprFact;
import expr.Factor;
import expr.IntFact;
import expr.Term;
import expr.VarFact;

import java.math.BigInteger;

public class Parser {
    private Lexer lexer;

    public Parser(Lexer lexer) {
        this.lexer = lexer;
    }

    private boolean isSign() {
        return (lexer.peek().equals("+") ||
                lexer.peek().equals("-"));
    }

    public Expr parseExpr() {
        Expr expr = new Expr();
        int sign = 1;
        if (isSign()) {
            if (lexer.peek().equals("-")) {
                sign = -1;
            }
            lexer.next();
        }
        expr.addTerm(parseTerm(sign));
        while (lexer.hasNext() && isSign()) {
            if (lexer.peek().equals("+")) {
                sign = 1;
            } else {
                sign = -1;
            }
            lexer.next();
            expr.addTerm(parseTerm(sign));
        }
        return expr;
    }

    public Term parseTerm(int outerSign) {
        int sign = outerSign;
        if (isSign()) {
            if (lexer.peek().equals("-")) {
                sign *= -1;
            }
            lexer.next();
        }
        Term term = new Term(sign);
        term.addFactor(parseFactor());
        while (lexer.hasNext() && lexer.peek().equals("*")) {
            lexer.next();
            term.addFactor(parseFactor());
        }
        return term;
    }

    public Factor parseFactor() {
        if (lexer.peek().equals("(")) {
            return parseExprFact();
        } else if (lexer.peek().equals("x")) {
            return parseVarFact();
        } else {
            return parseIntFact();
        }
    }

    public BigInteger getSignedNum() {
        BigInteger sign = new BigInteger("1");
        if (isSign()) {
            if (lexer.peek().equals("-")) {
                sign = sign.multiply(new BigInteger("-1"));
            }
            lexer.next();
        }
        BigInteger ret = new BigInteger(lexer.peek());
        ret = ret.multiply(sign);
        lexer.next();
        return ret;
    }

    public Factor parseVarFact() {
        BigInteger num;
        lexer.next();
        if (lexer.peek().equals("**")) {
            lexer.next();
            num = getSignedNum();
        } else {
            num = new BigInteger("1");
        }
        if (num.compareTo(new BigInteger("0")) != 0) {
            return new VarFact(num);
        } else {
            return new IntFact(new BigInteger("1"));
        }
    }

    public Factor parseIntFact() {
        BigInteger num = getSignedNum();
        return new IntFact(num);
    }

    public Factor parseExprFact() {
        lexer.next();
        Expr tmp = parseExpr();
        lexer.next();
        BigInteger num;
        if (lexer.peek().equals("**")) {
            lexer.next();
            num = getSignedNum();
        } else {
            num = new BigInteger("1");
        }
        if (num.compareTo(new BigInteger("0")) != 0) {
            return new ExprFact(tmp.getTerms(), num);
        } else {
            return new IntFact(new BigInteger("1"));
        }
    }
}
