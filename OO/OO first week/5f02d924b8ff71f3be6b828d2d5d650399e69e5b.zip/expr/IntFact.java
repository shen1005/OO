package expr;

import java.math.BigInteger;

public class IntFact implements Factor {
    private BigInteger val;

    public IntFact(BigInteger val) {
        this.val = val;
    }

    public BigInteger getVal() {
        return val;
    }

    public void setVal(BigInteger val) {
        this.val = val;
    }

    @Override
    public String toString() {
        return String.valueOf(val);
    }

    @Override
    public IntFact clone() {
        return new IntFact(val);
    }
}
