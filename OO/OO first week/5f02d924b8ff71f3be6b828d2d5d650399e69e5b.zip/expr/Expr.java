package expr;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

public class Expr {
    private ArrayList<Term> terms;

    public Expr() {
        terms = new ArrayList<>();
    }

    public Expr(ArrayList<Term> terms) {
        this.terms = terms;
    }

    public ArrayList<Term> getTerms() {
        return terms;
    }

    public void addTerm(Term term) {
        terms.add(term);
    }

    public void removeTerm(Term term) {
        terms.remove(term);
    }

    public String toString() {
        if (terms.size() == 0) {
            return "0";
        }
        String ret = " ";
        Iterator<Term> ite = terms.iterator();
        if (ite.hasNext()) {
            Term term = ite.next();
            if (term.getSign() == -1) {
                ret += "- ";
            }
            ret += term.toString();
        }
        while (ite.hasNext()) {
            Term term = ite.next();
            if (term.getSign() == -1) {
                ret += " - ";
            } else {
                ret += " + ";
            }
            ret += term.toString();
        }
        return ret;
    }

    private void simplify() {
        for (Term term : terms) {
            term.simplify();
        }
    }

    private void optimize() {
        if (terms.size() == 0) {
            return;
        }
        if (terms.get(0).getSign() == -1) {
            for (int j = 0;j < terms.size(); j++) {
                if (terms.get(j).getSign() == 1) {
                    Collections.swap(terms, 0, j);
                    break;
                }
            }
        }
    }

    private void merge() {
        simplify();
        HashSet<BigInteger> powers = new HashSet<>();
        for (Term term : terms) {
            powers.add(term.getPower());
        }
        for (BigInteger power : powers) {
            Iterator<Term> ite = terms.iterator();
            BigInteger coefficient = new BigInteger("0");
            while (ite.hasNext()) {
                Term term = ite.next();
                if (term.getPower().compareTo(power) == 0) {
                    if (term.getSign() == 1) {
                        coefficient = coefficient.add(term.getCoefficient());
                    } else {
                        coefficient = coefficient.subtract(term.getCoefficient());
                    }
                    ite.remove();
                }
            }
            int sign = 1;
            if (coefficient.compareTo(new BigInteger("0")) < 0) {
                coefficient = coefficient.multiply(new BigInteger("-1"));
                sign = -1;
            }
            if (coefficient.compareTo(new BigInteger("0")) != 0) {
                Term newTerm = new Term(sign);
                if (power.compareTo(new BigInteger("0")) == 0) {
                    newTerm.addFactor(new IntFact(coefficient));
                } else if (power.compareTo(new BigInteger("0")) > 0) {
                    if (coefficient.compareTo(new BigInteger("1")) != 0) {
                        newTerm.addFactor(new IntFact(coefficient));
                    }
                    newTerm.addFactor(new VarFact(power));
                }
                addTerm(newTerm);
            }
        }
        optimize();
    }

    public void expand() {
        simplify();
        boolean flag = true;
        while (flag) {
            flag = false;
            for (Term term : terms) {
                if (term.isSplittable()) {
                    term.split(this);
                    flag = true;
                    break;
                }
            }
        }
        merge();
        return;
    }
}
