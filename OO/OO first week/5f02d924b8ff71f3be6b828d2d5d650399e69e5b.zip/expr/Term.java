package expr;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;

public class Term {
    private ArrayList<Factor> factors;
    private int sign;

    public Term(int sign) {
        this.sign = sign;
        factors = new ArrayList<>();
    }

    public Term(ArrayList<Factor> factors, int sign) {
        this.factors = factors;
        this.sign = sign;
    }

    public ArrayList<Factor> getFactors() {
        return factors;
    }

    public void setFactors(ArrayList<Factor> factors) {
        this.factors = factors;
    }

    public int getSign() {
        return sign;
    }

    public void setSign(int sign) {
        this.sign = sign;
    }

    public void addFactor(Factor factor) {
        factors.add(factor);
    }

    public String toString() {
        Iterator<Factor> ite = factors.iterator();
        String ret = "";
        if (ite.hasNext()) {
            Factor factor = ite.next();
            ret += factor.toString();
        }
        while (ite.hasNext()) {
            ret += " * ";
            Factor factor = ite.next();
            ret += factor.toString();
        }
        return ret;
    }

    public void simplify() {
        IntFact intPro = new IntFact(new BigInteger("1"));
        VarFact varPro = new VarFact(new BigInteger("0"));
        Iterator<Factor> ite = factors.iterator();
        while (ite.hasNext()) {
            Factor factor = ite.next();
            if (factor instanceof  IntFact) {
                intPro.setVal(intPro.getVal().multiply(((IntFact) factor).getVal()));
                ite.remove();
            } else if (factor instanceof  VarFact) {
                varPro.setExp(varPro.getExp().add(((VarFact) factor).getExp()));
                ite.remove();
            }
        }
        if (intPro.getVal().compareTo(new BigInteger("0")) < 0) {
            sign *= -1;
            intPro.setVal(intPro.getVal().multiply(new BigInteger("-1")));
        }
        if (intPro.getVal().compareTo(new BigInteger("0")) == 0) {
            ite = factors.iterator();
            while (ite.hasNext()) {
                Factor factor = ite.next();
                ite.remove();
            }
            factors.add(intPro);
            return;
        }
        if (varPro.getExp().compareTo(new BigInteger("0")) != 0) {
            if (intPro.getVal().compareTo(new BigInteger("1")) != 0) {
                factors.add(intPro);
            }
            factors.add(varPro);
        } else {
            factors.add(intPro);
        }
    }

    public BigInteger getCoefficient() {
        BigInteger intPro = new BigInteger("1");
        for (Factor factor : factors) {
            if (factor instanceof IntFact) {
                intPro = intPro.multiply(((IntFact) factor).getVal());
            }
        }
        return intPro;
    }

    public BigInteger getPower() {
        BigInteger expSum = new BigInteger("0");
        for (Factor factor : factors) {
            if (factor instanceof VarFact) {
                expSum = expSum.add(((VarFact) factor).getExp());
            }
        }
        return expSum;
    }

    public boolean isSplittable() {
        for (Factor factor : factors) {
            if (factor instanceof ExprFact) {
                return true;
            }
        }
        return false;
    }

    public void split(Expr expr) {
        for (Factor factor : factors) {
            if (factor instanceof ExprFact) {
                //((ExprFact) factor).expand();
                if (((ExprFact) factor).getExp().compareTo(new BigInteger("1")) > 0) {
                    ((ExprFact) factor).setExp(
                            ((ExprFact) factor).getExp().subtract(new BigInteger("1")));
                } else {
                    factors.remove(factor);
                }
                ArrayList<Term> terms = ((ExprFact) factor).getTerms();
                for (Term term : terms) {
                    ArrayList<Factor> tmp = new ArrayList<>();
                    for (Factor fact : factors) {
                        tmp.add(fact.clone());
                    }
                    tmp.addAll(term.getFactors());
                    Term newTerm = new Term(tmp,sign * term.getSign());
                    expr.addTerm(newTerm);
                }
                expr.removeTerm(this);
                break;
            }
        }
    }
}
