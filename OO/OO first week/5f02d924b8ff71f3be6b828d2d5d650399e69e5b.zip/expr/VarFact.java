package expr;

import java.math.BigInteger;

public class VarFact implements Factor {
    private BigInteger exp;

    public VarFact(BigInteger exp) {
        this.exp = exp;
    }

    public BigInteger getExp() {
        return exp;
    }

    public void setExp(BigInteger exp) {
        this.exp = exp;
    }

    @Override
    public String toString() {
        if (exp.compareTo(new BigInteger("2")) > 0) {
            return "x ** " + String.valueOf(exp);
        } else if (exp.compareTo(new BigInteger("2")) == 0) {
            return "x * x";
        } else {
            return "x";
        }
    }

    @Override
    public VarFact clone() {
        return new VarFact(exp);
    }
}
