package expr;

import java.math.BigInteger;
import java.util.ArrayList;

public class ExprFact extends Expr implements Factor {
    private BigInteger exp;

    public ExprFact(ArrayList<Term> terms, BigInteger exp) {
        super(terms);
        this.exp = exp;
    }

    public void setExp(BigInteger exp) {
        this.exp = exp;
    }

    public BigInteger getExp() {
        return exp;
    }

    @Override
    public String toString() {
        String ret = "(" + super.toString() + ")";
        if (exp.compareTo(new BigInteger("1")) > 0) {
            ret += " ** " + String.valueOf(exp);
        }
        return ret;
    }

    @Override
    public ExprFact clone() {
        return new ExprFact(getTerms(),exp);
    }
}
