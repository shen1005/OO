package expr;

public interface Factor {

    public String toString();

    public Factor clone();
}
