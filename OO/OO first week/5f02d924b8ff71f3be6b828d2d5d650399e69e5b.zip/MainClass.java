import expr.Expr;
import com.oocourse.spec1.ExprInput;
import com.oocourse.spec1.ExprInputMode;

public class MainClass {
    public static void main(String[] args) {
        ExprInput scanner = new ExprInput(ExprInputMode.NormalMode);
        String toExpr = scanner.readLine();
        Lexer lexer = new Lexer(toExpr.replaceAll("[ \\t]",""));
        Parser parser = new Parser(lexer);
        Expr expr = parser.parseExpr();
        expr.expand();
        System.out.println(expr.toString());
    }
}
