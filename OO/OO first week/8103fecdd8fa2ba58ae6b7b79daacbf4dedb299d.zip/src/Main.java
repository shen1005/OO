import com.oocourse.spec1.ExprInput;
import com.oocourse.spec1.ExprInputMode;
import expr.Expr;

public class Main {
    public static void main(String[] args) {
        // 实例化一个ExprInput类型的对象scanner
        // 由于是一般读入模式，所以我们实例化时传递的参数为ExprInputMode.NormalMode
        ExprInput scanner = new ExprInput(ExprInputMode.NormalMode);

        // 一般读入模式下，读入一行字符串时使用readLine()方法，在这里我们使用其读入表达式
        String input = scanner.readLine();
        // 表达式括号展开相关的逻辑
        input = delBlank(input);
        Lexer lex = new Lexer(input);
        Parse parse = new Parse(lex);
        Expr expr = parse.parseExpr();
        //System.out.println(expr);
        String output = expr.simplify().toString()
                .substring(1,expr.simplify().toString().length() - 1);
        System.out.println(output);

    }

    public static String delBlank(String input)
    {
        StringBuilder ret = new StringBuilder();
        for (int i = 0;i < input.length();i++)
        {
            char c = input.charAt(i);
            if (c != ' ' && c != '\t')
            {
                ret.append(c);
            }
        }
        return ret.toString();
    }

}
