import expr.Factor;
import expr.Term;
import expr.ConstFactor;
import expr.Expr;
import expr.PowerFunct;
import expr.VarFactor;
import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parse {
    private final Lexer lex;
    private final Pattern numPattern = Pattern.compile("^\\d*$");

    public Parse(Lexer lex)
    {
        this.lex = lex;
    }

    public Expr parseExpr()
    {
        Expr expr = new Expr();
        expr.addTerm(parseTerm());
        while (lex.getCursor().equals("+") | lex.getCursor().equals("-"))
        {
            expr.addTerm(parseTerm());
        }
        return expr;
    }

    /*我们认为正负号是+/-1,属于常数因子,所以要把所有的正负号都清楚了再来判断factor,减轻factor 的工作*/

    public Term parseTerm()
    {
        Term term = new Term();
        String coef = getCoef();
        term.addFactor(new ConstFactor(coef));
        term.addFactor(parseFactor());
        while (lex.getCursor().equals("*"))
        {
            lex.next();
            coef = getCoef();
            term.addFactor(new ConstFactor(coef));
            term.addFactor(parseFactor());
        }
        return term;
    }

    public Factor parseFactor()
    {
        if (lex.getCursor().equals("("))
        {
            lex.next();
            Factor base = parseExpr();
            lex.next(); // remove )
            // 判断有无指数
            return parseIndex(base);
        } else
        {
            Matcher matcher = numPattern.matcher(lex.getCursor());
            if (matcher.find()) //constfactor
            {
                String ret = lex.getCursor();
                lex.next();
                return new ConstFactor(ret);
            } else //var / powerfunct
            {
                VarFactor var = new VarFactor(lex.getCursor());
                lex.next();
                return parseIndex(var);
            }
        }
    }

    public String getCoef()
    {
        BigInteger tmpCoef = new BigInteger("1");
        while (lex.getCursor().equals("-") | lex.getCursor().equals("+"))
        {
            tmpCoef = tmpCoef.multiply(new BigInteger(String.format("%s1",lex.getCursor())));
            lex.next();
        }
        return  tmpCoef.toString();
    }

    public Factor parseIndex(Factor base)
    {
        if (lex.getCursor().equals("*") && lex.peek().equals("*"))
        {
            lex.next();
            lex.next();
            if (lex.getCursor().equals("+") | lex.getCursor().equals("-"))
            {
                lex.next();
            }
            Factor ret =  new PowerFunct(base,new BigInteger(lex.getCursor()));
            lex.next();
            return ret;
        }
        else
        {
            return base;
        }
    }
}
