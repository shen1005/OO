package expr;

import java.math.BigInteger;

public class PowerFunct implements Factor {
    private Factor base;
    private BigInteger index;

    public PowerFunct(Factor base, BigInteger index) {
        this.base = base;
        this.index = index;
    }

    public PowerFunct(Factor base, String index) {
        this.base = base;
        this.index = new BigInteger(index);
    }

    public PowerFunct() {}

    public Factor getBase() {
        return base;
    }

    public BigInteger getIndex() {
        return index;
    }

    public void addIndex(BigInteger index) {
        this.index = this.index.add(index);
    }

    public void addIndex(String index) {
        this.index = this.index.add(new BigInteger(index));
    }

    @Override
    public String toString()
    {
        if (index.equals(new BigInteger("1")))
        {
            return base.toString();
        } else
        {
            return String.format("%s**%s",base.toString(),index.toString());
        }
    }

    @Override
    public Factor simplify()
    {
        if (index.equals(new BigInteger("1")))
        {
            return base.simplify();
        } else if (index.equals(new BigInteger("0"))
                | (base instanceof ConstFactor && base.equals(new ConstFactor("1"))))
        {
            return new ConstFactor("1");
        } else if (base instanceof Expr)
        {
            Term tmpTerm = new Term();
            for (BigInteger i = new BigInteger("0"); i.compareTo(index) < 0;
                 i = i.add(new BigInteger("1")))
            {
                tmpTerm.addFactor(base);
            }
            return tmpTerm.simplify(); //如果base是常数,simplify之后就只剩一个常数了
        } else
        {
            return new PowerFunct(base.simplify(),index); //只有一种情况返回PowerFunct,那就是base是变量,并且他们的
        }
    }

    @Override
    public boolean equals(Object o)
    {
        if (o instanceof PowerFunct)
        {
            return ((PowerFunct) o).getBase().equals(base)
                    && ((PowerFunct) o).getIndex().equals(index);
        } else  //o和他的base相同
        {
            return false;
        }
    }

    @Override
    public Factor merge(Factor o) {
        if (o instanceof PowerFunct)
        {
            addIndex((((PowerFunct)o).getIndex()));
        } else {
            addIndex("1");
        }
        return this;

    }
}
