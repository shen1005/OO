package expr;

import java.math.BigInteger;
import java.util.ArrayList;

public class Expr implements Factor,Merge {
    private ArrayList<Factor> terms;

    public Expr() {
        this.terms = new ArrayList<>();
    }

    public ArrayList<Factor> getTerms()
    {
        return terms;
    }

    public void addTerm(Factor newTerm)
    {
        terms.add(newTerm);
    }

    public void setTerms(ArrayList<Factor> terms)
    {
        this.terms = terms;
    }

    public void clearTerms()
    {
        this.terms = new ArrayList<>();
    }

    @Override
    public Factor simplify()
    {
        ArrayList<Factor> unfoldTerms = new ArrayList<>();
        /*
        * 1. 获得每一个因子的化简
        * 2. 打开括号
        * 3. 合并同类项()之所以不单独把常数先合并,因为括号里面可能由常数.而Term中的常数因子因为是乘法,所以不存在
        * */
        //获得因子的化简和打开括号()Term的化简就已经把括号化简到了表达式项级别,直接打开括号就行
        for (Factor term : terms)
        {
            Factor tmpTerm = term.simplify();
            if (((Term) tmpTerm).getFactors().get(0) instanceof Expr) {
                unfoldTerms.addAll(
                        (
                                (Expr) (((Term) tmpTerm).getFactors().get(0))
                        ).getTerms());
            } else {
                unfoldTerms.add(tmpTerm);
            }
        }

        //合并同类项
        setTerms(mergeFactors(unfoldTerms));
        // 除0
        for (int i = 0;i < terms.size();i++)
        {
            if (((Term)terms.get(i)).getCoef().equals(new BigInteger("0")))
            {
                terms.remove(i);
                i--;
            }
        }

        return this;
    }

    @Override
    public String toString()
    {
        if (terms.size() != 0)
        {
            StringBuilder sb = new StringBuilder();
            sb.append("(" + terms.get(0));
            for (int i = 1; i < terms.size(); i++) {
                if (((Term)terms.get(i)).getCoef().compareTo(new BigInteger("0")) < 0)
                {
                    sb.append(terms.get(i).toString());
                } else
                {
                    sb.append("+" + terms.get(i).toString());
                }
            }
            sb.append(")");
            return sb.toString();
        } else
        {
            return "(0)";
        }

    }

    @Override
    public boolean equals(Object o)
    {
        return false; //表达式类如果是表达式就没有机会使用equal方法,
        // 如果是表达式项,那么这个表达式项在simplify阶段中会被开包装,
        // 如果是表达式因子,term的simplify会将其变成表达式项
    }

    @Override
    public Factor merge(Factor o) { //表达式直接不会合并,
        // 因为如果是表达式,不会调用这个函数,
        // 如果是表达式项,那么就是这个是项的因子,调用的是项的merge
        // 如果是表达式因子,那么表达式因子的化简是打开指数,不能增加指数,接着打开括号
        return null;
    }

    @Override
    public ArrayList<Factor> mergeFactors(ArrayList<Factor> factors) //Term之间的合并,是加法级别的合并,所以必须要完全准确
    {
        boolean[] used = new boolean[factors.size()];
        ArrayList<Factor> retTerms = new ArrayList<>();
        for (int i = 0; i < factors.size(); i++) {
            Factor newFactor = factors.get(i);
            if (!used[i])
            {
                for (int j = i + 1; j < factors.size(); j++) {
                    if (factors.get(j).equals(newFactor) && !used[j])
                    {
                        newFactor = newFactor.merge(factors.get(j));
                        used[j] = true;
                    }
                }
                used[i] = true;
                retTerms.add(newFactor);
            }

        }
        return retTerms;
    }
}
