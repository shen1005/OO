package expr;

import java.util.ArrayList;

public interface Merge {
    ArrayList<Factor> mergeFactors(ArrayList<Factor> factors);
}
