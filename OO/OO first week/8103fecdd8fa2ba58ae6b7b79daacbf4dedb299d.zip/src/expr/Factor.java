package expr;

public interface Factor {
    Factor simplify();

    String toString();

    boolean equals(Object o);

    Factor merge(Factor o);//这个函数不允许递归调用

}
