package expr;

import java.math.BigInteger;

public class ConstFactor implements Factor {
    private BigInteger num;

    public ConstFactor(){}

    public ConstFactor(String num) {
        this.num = new BigInteger(num);
    }

    public ConstFactor(BigInteger num) {
        this.num = num;
    }

    public void setNum(BigInteger num) {
        this.num = num;
    }

    public BigInteger getNum() {
        return num;
    }

    public void addNum(BigInteger num)
    {
        this.num = this.num.add(num);
    }

    @Override
    public Factor simplify() { return this; }

    @Override
    public String toString() { return num.toString(); }

    @Override
    public boolean equals(Object o)
    {
        return o instanceof ConstFactor;
    }

    @Override
    public Factor merge(Factor o) {
        ConstFactor tmp = (ConstFactor) o;
        this.addNum(tmp.getNum());
        return this;
    }
}
