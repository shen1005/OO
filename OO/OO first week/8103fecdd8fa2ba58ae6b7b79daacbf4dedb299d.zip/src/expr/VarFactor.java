package expr;

public class VarFactor implements Factor {
    private String var;

    public VarFactor() {}

    public VarFactor(String var) {
        this.var = var;
    }

    public String getVar() { return var; }

    @Override
    public Factor simplify() {
        return this;
    }

    @Override
    public String toString() { return var.toString(); }

    @Override
    public boolean equals(Object o) {
        if (o instanceof VarFactor)
        {
            return var.equals(((VarFactor)o).getVar());
        }
        else
        {
            return false;
        }
    }

    @Override
    public Factor merge(Factor o) { //变量的合并称为PowerFunct,他的函数被调用,那么它一定是因子
        if (o instanceof PowerFunct)
        {
            ((PowerFunct)o).addIndex("1");
            return o;
        }
        else
        {
            return new PowerFunct(this,"2");
        }
    }

}
