package expr;

import java.math.BigInteger;
import java.util.ArrayList;

public class Term implements Factor,Merge {
    private ArrayList<Factor> factors;

    public Term() {
        this.factors = new ArrayList<>();
    }

    public void setFactors(ArrayList<Factor> factors) {
        this.factors = factors;
    }

    public ArrayList<Factor> getFactors() {
        return factors;
    }

    public void addFactor(Factor newFactor)
    {
        this.factors.add(newFactor);
    }

    public void addAllFactors(ArrayList<Factor> factors)
    {
        this.factors.addAll(factors);
    }

    public BigInteger getCoef()
    {
        if (factors.get(0) instanceof ConstFactor)
        {
            return ((ConstFactor)factors.get(0)).getNum();
        } else
        {
            return new BigInteger("1");
        }
    }

    private ArrayList<Factor> unfoldFactors(ArrayList<Factor> mergeFactors, boolean hasExpr)
    {
        if (hasExpr)
        {
            Expr receiver = new Expr();
            receiver.addTerm(new Term());
            for (Factor eachFactor:mergeFactors)
            {

                if (eachFactor instanceof Expr)
                {
                    /*
                    1.将所有的factor加入Expr的term中 解掉前面term的包装
                    将Expr simplify(保证Expr里面没有Expr,也就是两个括号相乘的问题)
                    将expr放入retFactors
                    */
                    Expr tmpExpr = new Expr();
                    tmpExpr.setTerms(receiver.getTerms());
                    receiver.clearTerms();
                    for (Factor poster1:tmpExpr.getTerms())
                    {
                        for (Factor poster2:((Expr) eachFactor).getTerms())
                        {
                            Term tmpTerm = new Term();
                            tmpTerm.addAllFactors(((Term)poster1).getFactors());
                            tmpTerm.addAllFactors(((Term)poster2).getFactors());
                            receiver.addTerm(tmpTerm);
                        }

                    }
                } else
                {
                    for (Factor eachTerm:receiver.getTerms())
                    {
                        if (eachTerm instanceof Term)
                        {
                            ((Term) eachTerm).addFactor(eachFactor);
                        }
                    }
                }
            }
            ArrayList<Factor> ret = new ArrayList<>();
            ret.add(receiver.simplify());
            return ret;
        }
        return  mergeFactors;
    }

    @Override
    public Factor simplify()
    {
        boolean hasExpr = false;
        ArrayList<Factor> simplifyFactors = new ArrayList<>();
        ConstFactor coef = new ConstFactor("1");
        /*
        1.获得每一个因子的化简
        2.将常数合并并放在第一排
        */
        for (Factor factor : factors)
        {
            /*如果是term就要全部加入*/
            Factor newFactor = factor.simplify();
            /*将powerFunct的simplify返回的Term全部合并*/
            if (newFactor  instanceof Expr) {
                hasExpr = true;
            }
            if (newFactor instanceof Term) {
                simplifyFactors.addAll(((Term)newFactor).getFactors());
                hasExpr = true;
            } else if (newFactor instanceof ConstFactor) {
                //合并常数项
                coef.setNum(coef.getNum().multiply(((ConstFactor) newFactor).getNum()));

            } else {

                simplifyFactors.add(newFactor);

            }
        }
        simplifyFactors.add(0,coef);
        /*
        * 合并同类项
        * */
        ArrayList<Factor> mergeFactors = mergeFactors(simplifyFactors);
        /*
        * 展开括号*/
        setFactors(unfoldFactors(mergeFactors,hasExpr));
        return this;

    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        if (factors.size() != 1)
        {
            if (getCoef().equals(new BigInteger("-1")))
            {
                sb.append("-");
            } else if (!getCoef().equals(new BigInteger("1")))
            {
                sb.append(getCoef().toString() + "*");
            }
            for (int i = 1;i < factors.size() - 1; i++)
            {
                sb.append(factors.get(i) + "*");
            }
            sb.append(factors.get(factors.size() - 1));
        } else
        {
            sb.append(getCoef().toString());
        }
        return sb.toString();
    }

    @Override
    public boolean equals(Object o)
    {
        /*除了常量之外都相同*/
        if (o instanceof Term && this.factors.size() == ((Term)o).getFactors().size())
        {
            Term tmp = ((Term)o);
            for (int i = 0;i < tmp.getFactors().size();i++)
            {
                Factor target = tmp.getFactors().get(i);
                if (!(tmp.getFactors().get(i) instanceof ConstFactor))
                {
                    if (!getFactors().contains(target))
                    {
                        return false;
                    }
                }
            }
            for (int i = 0;i < factors.size();i++)
            {
                if (!(getFactors().get(i) instanceof ConstFactor))
                {
                    if (!tmp.getFactors().contains(
                            getFactors().get(i)))
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public Factor merge(Factor o) { //合并系数即可
        Term tmp = (Term)o;
        if (this.getFactors().get(0) instanceof ConstFactor
                && tmp.getFactors().get(0) instanceof ConstFactor)
        {
            ((ConstFactor)this.getFactors().get(0)).addNum(
                            ((ConstFactor)tmp.getFactors().get(0))
                            .getNum());
            return this;
        } else
        {
            System.out.println("Term format error");
            return null;
        }
    }

    @Override
    public ArrayList<Factor> mergeFactors(ArrayList<Factor> factors) {
        boolean[] used = new boolean[factors.size()];
        ArrayList<Factor> retFactors = new ArrayList<>();
        for (int i = 0; i < factors.size(); i++) {
            Factor newFactor = factors.get(i);
            if (!used[i])
            {
                for (int j = i + 1; j < factors.size(); j++) {
                    if ((factors.get(j).equals(newFactor)
                            | isBaseEquals(newFactor,factors.get(j)))
                            && !used[j])
                    {
                        newFactor = newFactor.merge(factors.get(j));
                        used[j] = true;
                    }
                }
                used[i] = true;
                retFactors.add(newFactor);
            }
        }
        return retFactors;
    }

    public boolean isBaseEquals(Factor main,Factor sub)
    {
        if (main instanceof VarFactor)
        {
            if (sub instanceof PowerFunct)
            {
                return main.equals(((PowerFunct)sub).getBase());
            } else if (sub instanceof VarFactor)
            {
                return main.equals(sub);
            }
            return false;
        } else if (main instanceof PowerFunct)
        {
            if (sub instanceof PowerFunct)
            {
                return ((PowerFunct)main).getBase().equals(((PowerFunct)sub).getBase());
            } else if (sub instanceof VarFactor)
            {
                return sub.equals(((PowerFunct)main).getBase());
            }
            return false;
        }
        return false;
    }
}

