
import static java.lang.Character.isDigit;

public class Lexer {
    private String input;
    private int pos;
    private String cursor;

    public Lexer(String input) {
        this.input = input;
        pos = 0;
        this.next();
    }

    public Lexer() {}

    private String getNum()
    {
        StringBuilder ret = new StringBuilder();
        while (pos < input.length() && isDigit(input.charAt(pos)))
        {
            ret.append(input.charAt(pos));
            pos++;
        }
        return ret.toString();
    }

    public void next()
    {
        if (pos == input.length()) {
            return;
        }
        if (isDigit(input.charAt(pos)))
        {
            cursor = getNum();
        } else
        {
            cursor = String.valueOf(input.charAt(pos));
            pos++;
        }
    }

    public String getCursor()
    {
        return  cursor;
    }

    public String peek() //返回Cursor下一个值
    {
        if (pos > input.length() - 1)
        {
            return "";
        }
        else
        {
            return String.valueOf(input.charAt(pos));
        }
    }
}
