import expr.Expr;
import expr.Factor;
import expr.Number;
import expr.Term;
import expr.Xexp;

import java.math.BigInteger;

public class Parser {
    private final Lexer lexer;

    public Parser(Lexer lexer) {
        this.lexer = lexer;
    }

    public Expr parseExpr() {
        //System.out.println("Expr:"+lexer.peek());
        Expr expr = new Expr();
        if (lexer.peek().equals("-")) {
            lexer.next();
            expr.addTerm(parseTerm(false));
        } else if (lexer.peek().equals("+")) {
            //System.out.println("2?");
            lexer.next();
            expr.addTerm(parseTerm(true));
        } else {
            expr.addTerm(parseTerm(true));
        }
        while (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            if (lexer.peek().equals("+")) {
                lexer.next();
                expr.addTerm(parseTerm(true));
            } else {
                lexer.next();
                expr.addTerm(parseTerm(false));
            }
        }
        //for (Atompoly atompoly : expr.getSum()) {
        //System.out.print("expr??? " + atompoly.getCon());
        //System.out.print(" ");
        // System.out.println(atompoly.getExp());
        //}
        return expr;
    }

    public Term parseTerm(boolean positive) {
        //System.out.println("Term:"+lexer.peek());
        Term term = new Term(positive);
        term.addFactor(parseFactor());
        //System.out.println("????"+lexer.peek());
        //if (lexer.peek().equals(")")) {
        //lexer.next();
        //}
        while (lexer.peek().equals("*")) {
            lexer.next();
            term.addFactor(parseFactor());
        }
        return term;
    }

    public Factor parseFactor() {
        //System.out.println("Factor:"+lexer.peek());
        if (lexer.peek().equals("(")) {
            //System.out.println("FIRST?");
            lexer.next();
            Factor expr = parseExpr();
            //System.out.println("...."+lexer.peek());
            lexer.next();
            //System.out.println("....."+lexer.peek());
            return expr;
        } else if (lexer.peek().equals("x")) {
            lexer.next();
            lexer.next();
            lexer.next();
            //System.out.println("!!!!"+lexer.peek());
            BigInteger exp = new BigInteger(lexer.peek());
            lexer.next();
            Xexp xexp = new Xexp(exp);
            return xexp;
        } else {
            BigInteger num;
            if (lexer.peek().equals("-")) {
                lexer.next();
                num = new BigInteger(lexer.peek()).negate();
            } else if (lexer.peek().equals("+")) {
                lexer.next();
                num = new BigInteger(lexer.peek());
            } else {
                num = new BigInteger(lexer.peek());
            }

            lexer.next();
            Number number = new Number(num);
            //lexer.next();
            return number;
        }
    }
}
