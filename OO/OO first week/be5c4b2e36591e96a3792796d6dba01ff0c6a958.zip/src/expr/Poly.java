package expr;

import java.util.ArrayList;

public class Poly {
    private ArrayList<Atompoly> polySet;

    private Poly() {
        this.polySet = new ArrayList<Atompoly>();
    }
}
