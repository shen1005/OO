package expr;

import java.math.BigInteger;
import java.util.ArrayList;

public class Term {
    // private final HashSet<Factor> factors;
    private ArrayList<Atompoly> poly = new ArrayList<Atompoly>();

    private boolean positive;

    public ArrayList<Atompoly> getPoly() {
        return poly;
    }

    public boolean isPositive() {
        return positive;
    }

    public Term(boolean positive) {
        //this.factors = new HashSet<>();
        //this.poly = new ArrayList<Atompoly>();
        this.positive = positive;
    }

    public void addFactor(Factor factor) {
        //this.factors.add(factor);
        if (poly.isEmpty()) {
            if (factor instanceof Number) {
                poly = ((Number) factor).getSum();
                //for (Atompoly atompoly : poly) {
                //System.out.println("111&&&"+atompoly.getCon());
                //System.out.println("^^^"+atompoly.getExp());
                //}
            } else if (factor instanceof Xexp) {
                poly = ((Xexp) factor).getSum();
                //for (Atompoly atompoly : poly) {
                //  System.out.println("222&&&"+atompoly.getCon());
                //   System.out.println("^^^"+atompoly.getExp());
                //}
            } else if (factor instanceof Expr) {
                poly = ((Expr) factor).getSum();
                //for (Atompoly atompoly : poly) {
                //  System.out.println("333&&&"+atompoly.getCon());
                //   System.out.println("^^^"+atompoly.getExp());
                //}
            }
        } else {
            poly = calculate(factor);
            /*for (Atompoly atompoly : poly) {
                System.out.println("cal&&&"+atompoly.getCon());
                System.out.println("^^^"+atompoly.getExp());
            }*/
        }

    }

    public ArrayList<Atompoly> calculate(Factor factor) {
        ArrayList<Atompoly> sum1 = new ArrayList<>();
        if (factor instanceof Number) {
            BigInteger con = ((Number) factor).getNum();
            for (Atompoly atompoly : poly) {
                Atompoly atompoly1 = new Atompoly(atompoly.getCon().multiply(con),
                        atompoly.getExp());
                sum1.add(atompoly1);
            }
        } else if (factor instanceof Xexp) {
            BigInteger exp = ((Xexp) factor).getExp();
            for (Atompoly atompoly : poly) {
                Atompoly atompoly1 = new Atompoly(atompoly.getCon(), atompoly.getExp().add(exp));
                sum1.add(atompoly1);
            }
        } else if (factor instanceof Expr) {
            ArrayList<Atompoly> sum2 = ((Expr) factor).getSum();
            for (Atompoly atompoly : poly) {
                for (Atompoly atompoly2 : sum2) {
                    Atompoly atompoly1 = new Atompoly(atompoly.
                            getCon().multiply(atompoly2.getCon()),
                            atompoly.getExp().add(atompoly2.getExp()));
                    sum1.add(atompoly1);
                }
            }
        }
        /*for (Atompoly atompoly : sum1) {
            System.out.println("&&&"+atompoly.getCon());
            System.out.println("^^^"+atompoly.getExp());
        }*/
        return sum1;
    }

    /*public String toString() {
        Iterator<Factor> iter = factors.iterator();
        StringBuilder sb = new StringBuilder();
        sb.append(iter.next().toString());
        if (iter.hasNext()) {
            sb.append(" ");
            sb.append(iter.next().toString());
            sb.append(" *");
            while (iter.hasNext()) {
                sb.append(" ");
                sb.append(iter.next().toString());
                sb.append(" *");
            }
        }
        return sb.toString();
    }*/
}
