package expr;

import java.math.BigInteger;

public class Atompoly {
    private BigInteger con;
    private BigInteger exp;

    public BigInteger getCon() {
        return con;
    }

    public void setCon(BigInteger con) {
        this.con = con;
    }

    public BigInteger getExp() {
        return exp;
    }

    public void setExp(BigInteger exp) {
        this.exp = exp;
    }

    public Atompoly(BigInteger con, BigInteger exp) {
        this.con = con;
        this.exp = exp;
    }

}
