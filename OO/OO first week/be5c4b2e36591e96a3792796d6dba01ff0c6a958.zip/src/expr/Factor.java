package expr;

public interface Factor {

}
