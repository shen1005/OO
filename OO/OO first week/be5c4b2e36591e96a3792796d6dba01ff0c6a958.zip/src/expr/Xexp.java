package expr;

import java.math.BigInteger;
import java.util.ArrayList;

public class Xexp implements Factor {
    private final BigInteger exp;
    private ArrayList<Atompoly> sum = new ArrayList<Atompoly>();

    public BigInteger getExp() {
        return exp;
    }

    public ArrayList<Atompoly> getSum() {
        return sum;
    }

    public Xexp(BigInteger exp) {
        this.exp = exp;
        Atompoly atompoly = new Atompoly(BigInteger.valueOf(1),exp);
        this.sum.add(atompoly);
        //System.out.println("x^"+exp);
    }

    /*public String toString() {
        return this.exp.toString();
    }*/
}
