package expr;

import java.math.BigInteger;
import java.util.ArrayList;

public class Number implements Factor {
    private final BigInteger num;
    private ArrayList<Atompoly> sum = new ArrayList<Atompoly>();

    public BigInteger getNum() {
        return num;
    }

    public ArrayList<Atompoly> getSum() {
        return sum;
    }

    //private ArrayList<Atompoly> sum;

    public Number(BigInteger num) {
        this.num = num;
        Atompoly atompoly = new Atompoly(num, BigInteger.valueOf(0));
        this.sum.add(atompoly);
        //System.out.println(num);
    }
    /*public String toString() {
        return this.num.toString();
    }*/
}
