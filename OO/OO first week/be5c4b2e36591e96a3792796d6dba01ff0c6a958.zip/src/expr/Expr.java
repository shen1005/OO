package expr;

import java.util.ArrayList;

public class Expr implements Factor {
    //private final HashSet<Term> terms;
    private ArrayList<Atompoly> sum;

    //@Override
    public ArrayList<Atompoly> getSum() {
        return sum;
    }

    public Expr() {
        //this.terms = new HashSet<>();
        this.sum = new ArrayList<Atompoly>();
        //super.sum = new ArrayList<Atompoly>();
    }

    public void addTerm(Term term) {
        //this.terms.add(term);
        if (term.isPositive()) {
            sum.addAll(term.getPoly());
            // for (Atompoly atompoly : sum) {
            // System.out.println("fiall&&&"+atompoly.getCon());
            // System.out.println("^^^"+atompoly.getExp());
            // }
        } else {
            for (Atompoly atompoly : term.getPoly()) {
                Atompoly atompoly1 = new Atompoly(atompoly.getCon().negate(), atompoly.getExp());
                sum.add(atompoly1);
            }
            // for (Atompoly atompoly : sum) {
            //   System.out.println("bu&&&"+atompoly.getCon());
            //  System.out.println("^^^"+atompoly.getExp());
            //}
        }

    }
    /*public void calculate() {
        Iterator<Term> iter = terms.iterator();
        while (iter.hasNext()) {
            if(iter.next() )
        }
    }*/

    /*public String toString() {
        Iterator<Term> iter = terms.iterator();
        StringBuilder sb = new StringBuilder();
        sb.append(iter.next().toString());
        if (iter.hasNext()) {
            sb.append(" ");
            sb.append(iter.next().toString());
            sb.append(" +");
            while (iter.hasNext()) {
                sb.append(" ");
                sb.append(iter.next().toString());
                sb.append(" +");
            }
        }
        //return sb.toString();
    }*/
}