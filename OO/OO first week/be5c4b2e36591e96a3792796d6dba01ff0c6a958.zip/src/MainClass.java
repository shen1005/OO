import expr.Atompoly;
import expr.Expr;
import com.oocourse.spec1.ExprInput;
import com.oocourse.spec1.ExprInputMode;

import java.math.BigInteger;

public class MainClass {

    public static void main(String[] args) {
        ExprInput scanner = new ExprInput(ExprInputMode.NormalMode);
        //Scanner scanner = new Scanner(System.in);
        String input = scanner.readLine();
        Lexer lexer = new Lexer(input);
        Parser parser = new Parser(lexer);

        Expr expr = parser.parseExpr();
        BigInteger[] data = new BigInteger[9];
        //ArrayList<BigInteger> ans = new ArrayList<>();
        //BigInteger test;
        for (int i = 0; i <= 8; i++) {
            //ans.add(BigInteger.valueOf(0));
            data[i] = BigInteger.valueOf(0);
        }
        for (Atompoly atompoly : expr.getSum()) {
            if (atompoly.getExp().compareTo(BigInteger.valueOf(9)) < 0) {
                String k = atompoly.getExp().toString();
                //System.out.println("@#@#@ " + k);
                //data[Integer.parseInt(k)].add(atompoly.getCon());
                //(ans.get(Integer.parseInt(k))).(atompoly.getCon());
                //BigInteger tmp = ans.get(Integer.parseInt(k));
                //ans.set(Integer.parseInt(k)+1,tmp.add(atompoly.getCon()));
                //test1.add(atompoly.getCon());
                data[Integer.parseInt(k)] = data[Integer.parseInt(k)].add(atompoly.getCon());
                //System.out.print(atompoly.getCon());
                //System.out.print(" %^& ");
                //System.out.println(k);
            }
            //System.out.print(atompoly.getCon());
            //System.out.print(" %^& ");
            //System.out.println(atompoly.getExp());
        }
        int maxi = -1;
        for (int i = 0; i <= 8; i++) {
            if (data[i].compareTo(BigInteger.valueOf(0)) != 0) {
                maxi = Math.max(maxi, i);
            }
        }
        //System.out.println("RRRRRR" + maxi);
        if (data[8].compareTo(BigInteger.valueOf(0)) < 0) {
            if (data[8].compareTo(BigInteger.valueOf(-1)) == 0) {
                System.out.print("-x**" + 8);
            } else {
                System.out.print(data[8] + "*x**" + 8);
            }
            //System.out.print(data[i]+"*x**"+i);
        } else if (data[8].compareTo(BigInteger.valueOf(0)) > 0) {
            if (data[8].compareTo(BigInteger.valueOf(1)) == 0) {
                System.out.print("x**" + 8);
            } else {
                System.out.print(data[8] + "*x**" + 8);
            }
        }

        for (int i = 7; i >= 3; i--) {
            //System.out.print(i+" ");
            if (data[i].compareTo(BigInteger.valueOf(0)) < 0) {
                if (data[i].compareTo(BigInteger.valueOf(-1)) == 0) {
                    System.out.print("-x**" + i);
                } else {
                    System.out.print(data[i] + "*x**" + i);
                }
                //System.out.print(data[i]+"*x**"+i);
            } else if (data[i].compareTo(BigInteger.valueOf(0)) > 0) {
                if (data[i].compareTo(BigInteger.valueOf(1)) == 0) {
                    if (i < maxi) {
                        System.out.print("+");
                    }
                    System.out.print("x**" + i);
                } else {
                    if (i < maxi) {
                        System.out.print("+");
                    }
                    System.out.print(data[i] + "*x**" + i);
                }
            }
        }
        if (data[2].compareTo(BigInteger.valueOf(0)) < 0) {
            if (data[2].compareTo(BigInteger.valueOf(-1)) == 0) {
                System.out.print("-x*x");
            } else {
                System.out.print(data[2] + "*x*x");
            }
            //System.out.print(data[i]+"*x**"+i);
        } else if (data[2].compareTo(BigInteger.valueOf(0)) > 0) {
            if (data[2].compareTo(BigInteger.valueOf(1)) == 0) {
                if (2 < maxi) {
                    System.out.print("+");
                }
                System.out.print("x*x");
            } else {
                if (2 < maxi) {
                    System.out.print("+");
                }
                System.out.print(data[2] + "*x*x");
            }
        }
        if (data[1].compareTo(BigInteger.valueOf(0)) < 0) {
            if (data[1].compareTo(BigInteger.valueOf(-1)) == 0) {
                System.out.print("-x");
            } else {
                System.out.print(data[1] + "*x");
            }
            //System.out.print(data[i]+"*x**"+i);
        } else if (data[1].compareTo(BigInteger.valueOf(0)) > 0) {
            if (data[1].compareTo(BigInteger.valueOf(1)) == 0) {
                if (1 < maxi) {
                    System.out.print("+");
                }
                System.out.print("x");
            } else {
                if (1 < maxi) {
                    System.out.print("+");
                }
                System.out.print(data[1] + "*x");
            }
        }
        if (data[0].compareTo(BigInteger.valueOf(0)) < 0) {
            if (data[0].compareTo(BigInteger.valueOf(-1)) == 0) {
                System.out.print("-1");
            } else {
                System.out.print(data[0]);
            }
            //System.out.print(data[i]+"*x**"+i);
        } else if (data[0].compareTo(BigInteger.valueOf(0)) > 0) {
            if (data[0].compareTo(BigInteger.valueOf(1)) == 0) {
                if (0 < maxi) {
                    System.out.print("+");
                }
                System.out.print("1");
            } else {
                if (0 < maxi) {
                    System.out.print("+");
                }
                System.out.print(data[0]);
            }
        }
        if (maxi == -1) {
            System.out.print("0");
        }
        // System.out.println(expr);
    }
}
