public class Lexer {
    private final String input;
    private int pos = 0;
    private String curToken;

    public String prebuild1(String input) {
        StringBuilder sb = new StringBuilder();
        //System.out.println(input.length());
        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) != ' ') {
                sb.append(input.charAt(i));
                //System.out.println(input.charAt(i));
            }
        }
        return sb.toString();
    }

    public String prebuild2(String input) {
        StringBuilder sb = new StringBuilder();
        int k = -1;
        int g = -1;
        for (int i = 0; i < input.length(); i++) {
            //System.out.println("@@@"+input.charAt(i));
            if (input.charAt(i) == '(') {
                k = i;
            }
            //System.out.println("(:" + k);
            if (i + 2 < input.length() && input.substring(i, i + 2).
                    equals("**") && input.charAt(i - 1) == ')') {
                //System.out.println("(:" + k);
                //System.out.println("):" + (i-1));
                g = i - 1;
                StringBuilder sb1 = new StringBuilder();
                i = i + 2;
                if (input.charAt(i) == '+') {
                    i++;
                }
                while (i < input.length() && Character.isDigit(input.charAt(i))) {
                    sb1.append(input.charAt(i));
                    ++i;
                }
                int lll = Integer.valueOf(sb1.toString());
                //System.out.println("!!!"+sb.length());
                //System.out.println("!!!"+(g - k + 1));
                sb.setLength(sb.length() - (g - k + 1));
                //System.out.println("???"+sb.toString());
                if (lll == 0) {
                    sb.append("1");
                } else {
                    sb.append(input.substring(k, g + 1));
                    for (int j = 2; j <= lll; j++) {
                        sb.append("*");
                        sb.append(input.substring(k, g + 1));
                    }
                }
                i--;

            } else {
                //System.out.println("..."+i);
                sb.append(input.charAt(i));
            }
        }
        return sb.toString();
    }

    public String prebuild3(String input) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            if ((i + 3 < input.length() && input.charAt(i) == 'x' &&
                    input.substring(i, i + 3).equals("x**") == false) ||
                    (i + 3 >= input.length() && input.charAt(i) == 'x')) {
                sb.append("x**1");
            } else if (i + 3 < input.length() && input.substring(i, i + 3).equals("**+")) {
                sb.append("**");
                i += 2;
            } else if ((i + 2 < input.length() && (input.substring(i, i + 2).
                    equals("--") || input.substring(i, i + 2).equals("++")))) {
                sb.append("+");
                i += 1;
            } else if ((i + 2 < input.length() && (input.substring(i, i + 2).equals("+-")
                    || input.substring(i, i + 2).equals("-+")))) {
                sb.append("-");
                i += 1;
            } else {
                sb.append(input.charAt(i));
            }
        }
        return sb.toString();
    }

    public String prebuild4(String input) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            if (i + 3 < input.length() && input.substring(i, i + 3).equals("*+(")) {
                sb.append("*1*(");
                i += 2;
            } else if (i + 3 < input.length() && input.substring(i, i + 3).equals("*-(")) {
                sb.append("*-1*(");
                i += 2;
            } else {
                sb.append(input.charAt(i));
            }
        }
        return sb.toString();
    }

    public String prebuild5(String input) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            if (i + 2 < input.length() && input.substring(i, i + 2).equals("(+")) {
                sb.append("(");
                i += 1;
            } else {
                sb.append(input.charAt(i));
            }
        }
        return sb.toString();
    }

    public Lexer(String input) {
        String input1 = input.replaceAll("\\s*", "");
        this.input = prebuild5(prebuild4(prebuild3(prebuild3(prebuild2(prebuild1(input1))))));
        //System.out.println(prebuild5(prebuild4
        // (prebuild3(prebuild3(prebuild2(prebuild1(input1)))))));
        this.next();
    }

    private String getNumber() {
        StringBuilder sb = new StringBuilder();
        while (pos < input.length() && Character.isDigit(input.charAt(pos))) {
            sb.append(input.charAt(pos));
            ++pos;
        }
        return sb.toString();
    }

    public void next() {
        if (pos == input.length()) {
            return;
        }
        char c = input.charAt(pos);
        if (Character.isDigit(c)) {
            curToken = getNumber();
        } else if ("()+-*x".indexOf(c) != -1) {
            pos += 1;
            curToken = String.valueOf(c);
        }
    }

    public String peek() {
        return this.curToken;
    }
}
