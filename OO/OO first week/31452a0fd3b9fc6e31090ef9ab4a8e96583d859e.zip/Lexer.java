public class Lexer {
    private static final String BRACKET_NUM_CAL = "\\((?<fml>[^x]+)\\)";
    private final String formula;
    private int pos = 0;
    private String curToken;

    public Lexer(String str) {
        this.formula = preprocess(str);
        this.next();
    }

    public String preprocess(String input) {
        String str = input.replaceAll("[ \t]+", "");
        str = str.replace("++", "+");
        str = str.replace("+-", "-");
        str = str.replace("-+", "-");
        str = str.replace("--", "+");
        str = str.replace("++", "+");
        str = str.replace("+-", "-");
        str = str.replace("-+", "-");
        return str;
    }

    public void next() {
        if (pos == formula.length()) {
            return;
        }
        char c = formula.charAt(pos);
        if (Character.isDigit(c)) {
            curToken = getNumber();
        } else if (!(c == '*' && formula.charAt(pos + 1) == '*')) {
            pos++;
            curToken = String.valueOf(c);
        } else {
            pos += 2;
            curToken = "**";
        }
    }

    private String getNumber() {
        StringBuilder sb = new StringBuilder();
        while (pos < formula.length() && Character.isDigit(formula.charAt(pos))) {
            sb.append(formula.charAt(pos));
            pos++;
        }
        while (sb.indexOf("0") == 0) {
            sb.deleteCharAt(0);
        }
        if (sb.length() == 0) {
            sb.append("0");
        }
        return sb.toString();
    }

    public String peek() {
        return this.curToken;
    }
}
