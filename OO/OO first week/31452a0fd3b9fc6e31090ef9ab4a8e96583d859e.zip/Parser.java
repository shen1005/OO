import expr.Expr;
import expr.Variable;
import expr.Factor;
import expr.Term;

import java.math.BigInteger;

public class Parser {
    private final Lexer lexer;

    public Parser(Lexer lexer) {
        this.lexer = lexer;
    }

    public Expr parseExpr() {
        Expr expr = new Expr();
        if (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            boolean negative = lexer.peek().equals("-");
            lexer.next();
            expr.addTerm(parseTerm(negative));
        } else {
            expr.addTerm(parseTerm(Boolean.FALSE));
        }
        while (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            boolean negative = lexer.peek().equals("-");
            lexer.next();
            expr.addTerm(parseTerm(negative));
        }
        if (lexer.peek().equals("**")) {
            lexer.next();
            if (lexer.peek().equals("+")) {
                lexer.next();
            }
            expr.setPower(Integer.parseInt(lexer.peek()));
            lexer.next();
        }
        return expr;
    }

    public Term parseTerm(boolean negative) {
        Term term = new Term(negative);
        term.addFactor(parseFactor());
        while (lexer.peek().equals("*")) {
            lexer.next();
            term.addFactor(parseFactor());
        }
        return term;
    }

    public Factor parseFactor() {
        Factor factor;
        boolean negative = Boolean.FALSE;
        if (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            negative = lexer.peek().equals("-");
            lexer.next();
        }
        if (lexer.peek().equals("(")) {
            lexer.next();
            factor = parseExpr();
        } else if (lexer.peek().equals("x")) {
            factor = new Variable(negative, BigInteger.ONE, 1);
        } else {
            factor = new Variable(negative, new BigInteger(lexer.peek()), 0);
        }
        lexer.next();
        if (lexer.peek().equals(")")) {
            return factor;
        }
        if (lexer.peek().equals("**")) {
            lexer.next();
            if (lexer.peek().equals("+")) {
                lexer.next();
            }
            factor.setPower(Integer.parseInt(lexer.peek()));
            lexer.next();
        }
        return factor;
    }
}
