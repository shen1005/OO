package expr;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;

public class Expr implements Factor {
    private final HashSet<Term> terms;
    private int power;
    private HashMap<Integer, Variable> anss = new HashMap<>();

    public Expr() {
        this.terms = new HashSet<>();
        this.power = 1;
    }

    public void addTerm(Term term) {
        this.terms.add(term);
    }

    @Override
    public void setPower(int power) {
        this.power = power;
    }

    @Override
    public int getPower() {
        return this.power;
    }

    @Override
    public void setCoefficient(BigInteger coefficient) {

    }

    @Override
    public BigInteger getCoefficient() {
        return new BigInteger("1");
    }

    public void setAnss(HashMap<Integer, Variable> anss) {
        this.anss = anss;
    }

    public HashMap<Integer, Variable> getAnss() {
        return anss;
    }

    public void cal() {
        for (Term x: terms) {
            x.cal();
            for (Variable y: x.getAnss()) {
                if (anss.containsKey(y.getPower())) {
                    Variable old = anss.get(y.getPower());
                    BigInteger coefficient;
                    coefficient = old.getCoefficient().add(y.getCoefficient());
                    old.setCoefficient(coefficient);
                } else {
                    anss.put(y.getPower(), y);
                }
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Variable x: anss.values()) {
            if (x.getCoefficient().compareTo(BigInteger.ZERO) > 0) {
                sb.append("+");
            }
            if (!x.getCoefficient().equals(BigInteger.ZERO)) {
                if (x.getPower() > 0) {
                    if (x.getCoefficient().equals(BigInteger.ONE.negate())) {
                        sb.append("-x");
                    } else if (x.getCoefficient().equals(BigInteger.ONE)) {
                        sb.append("x");
                    } else if (!x.getCoefficient().equals(BigInteger.ZERO)) {
                        sb.append(x.getCoefficient());
                        sb.append("*x");
                    }
                    if (x.getPower() == 2) {
                        sb.append("*x");
                    } else if (x.getPower() > 2) {
                        sb.append("**");
                        sb.append(x.getPower());
                    }
                } else {
                    sb.append(x.getCoefficient());
                }
            }
        }
        if (sb.length() == 0) {
            sb.append("0");
        }
        if (sb.toString().contains("+")) {
            String[] ans = sb.toString().split("\\+", 2);
            return ans[1] + ans[0];
        } else {
            return sb.toString();
        }
    }
}
