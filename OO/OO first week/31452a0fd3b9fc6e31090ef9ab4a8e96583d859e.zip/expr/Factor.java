package expr;

import java.math.BigInteger;
import java.util.HashMap;

public interface Factor {
    void setPower(int power);

    int getPower();

    void setCoefficient(BigInteger coefficient);

    BigInteger getCoefficient();

    public HashMap<Integer, Variable> getAnss();
}
