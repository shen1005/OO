package expr;

import java.math.BigInteger;
import java.util.HashMap;

public class Variable implements Factor {
    private BigInteger coefficient;
    private int power;

    public Variable(boolean negative, BigInteger coefficient, int power) {
        if (negative) {
            this.coefficient = coefficient.negate();
        } else {
            this.coefficient = coefficient;
        }
        this.power = power;
    }

    @Override
    public void setPower(int power) {
        this.power = power;
    }

    @Override
    public int getPower() {
        return this.power;
    }

    @Override
    public void setCoefficient(BigInteger coefficient) {
        this.coefficient = coefficient;
    }

    @Override
    public BigInteger getCoefficient() {
        return this.coefficient;
    }

    @Override
    public HashMap<Integer, Variable> getAnss() {
        return null;
    }
}
