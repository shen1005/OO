package expr;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

public class Term {
    private final ConcurrentHashMap<Factor, Factor> factors;
    private boolean negative;
    private final HashSet<Variable> anss = new HashSet<>();

    public Term(boolean negative) {
        this.factors = new ConcurrentHashMap<>();
        this.negative = negative;
    }

    public HashSet<Variable> getAnss() {
        return anss;
    }

    public void addFactor(Factor factor) {
        this.factors.put(factor, factor);
    }

    public void cal() {
        Variable outer = calOuter();
        if (factors.size() == 0) {
            anss.add(outer);
            return;
        }
        Factor tmp = breakBracket();
        if (tmp == null) {
            return;
        }
        for (Variable x: tmp.getAnss().values()) {
            BigInteger coefficient = x.getCoefficient().multiply(outer.getCoefficient());
            int power = x.getPower() + outer.getPower();
            anss.add(new Variable(Boolean.FALSE, coefficient, power));
        }
    }

    private Variable calOuter() {
        BigInteger coefficient = new BigInteger("1");
        int power = 0;

        for (Factor x: factors.values()) {
            if (x instanceof Expr) {
                ((Expr) x).cal();
                continue;
            }
            coefficient = coefficient.multiply(x.getCoefficient());
            power += x.getPower();
            factors.remove(x);
        }

        if (this.negative) {
            coefficient = coefficient.negate();
            this.negative = Boolean.FALSE;
        }
        return new Variable(Boolean.FALSE, coefficient, power);
    }

    private Factor breakBracket() {
        Factor former = null;
        for (Factor x: factors.values()) {
            if (x == null) { break; }
            if (x.getPower() == 0) {
                factors.remove(x);
                Expr tmp = new Expr();
                HashMap<Integer, Variable> tmpAns = new HashMap<>();
                Variable one = new Variable(Boolean.FALSE, BigInteger.ONE, 0);
                tmpAns.put(0, one);
                tmp.setAnss(tmpAns);
                factors.put(tmp, tmp);
                continue;
            }
            breakPower(x, x.getPower());
            x.setPower(1);
        }
        for (Factor x: factors.values()) {
            if (x == null) { break; }
            if (former == null) {
                former = x;
                continue;
            }
            Factor z = new Expr();
            for (Variable i: x.getAnss().values()) {
                for (Variable j: former.getAnss().values()) {
                    BigInteger coefficient = i.getCoefficient().multiply(j.getCoefficient());
                    int power = i.getPower() + j.getPower();
                    if (z.getAnss().containsKey(power)) {
                        Variable old = z.getAnss().get(power);
                        coefficient = old.getCoefficient().add(coefficient);
                        old.setCoefficient(coefficient);
                    } else {
                        z.getAnss().put(power, new Variable(negative, coefficient, power));
                    }
                }
            }
            factors.remove(former);
            ((Expr) x).setAnss(z.getAnss());
            former = x;
        }
        return former;
    }

    private void breakPower(Factor factor, int power) {
        for (int i = 1; i < power; i++) {
            Expr copy = new Expr();
            copy.setAnss(factor.getAnss());
            factors.put(copy, copy);
        }
    }
}
