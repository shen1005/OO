package expr;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class Expr extends Calculate implements Factor  {
    private final HashSet<Term> terms;

    public Expr() {
        this.terms = new HashSet<>();

        BigInteger b0 = new BigInteger("0");
        BigInteger b1 = new BigInteger("0");
        BigInteger b2 = new BigInteger("0");
        BigInteger b3 = new BigInteger("0");
        BigInteger b4 = new BigInteger("0");
        BigInteger b5 = new BigInteger("0");
        BigInteger b6 = new BigInteger("0");
        BigInteger b7 = new BigInteger("0");
        BigInteger b8 = new BigInteger("0");

        super.cal = new HashMap<Integer, BigInteger>() {
            {
                put(0, b0);
                put(1, b1);
                put(2, b2);
                put(3, b3);
                put(4, b4);
                put(5, b5);
                put(6, b6);
                put(7, b7);
                put(8, b8);
            }
        };
    }

    public void addTerm(Term term) {
        this.terms.add(term);
    }

    public HashMap<Integer, BigInteger> addHashMap(
            HashMap<Integer, BigInteger> a, HashMap<Integer, BigInteger> b) {
        HashMap<Integer, BigInteger> res = new HashMap<>(9);

        for (int i = 0;i < 9;i++) {
            res.put(i, a.get(i).add(b.get(i)));
        }

        return res;
    }

    @Override
    public HashMap<Integer, BigInteger> calculate() {      //实现加法, assert此时无前导零（已在因子处全部消除）
        Iterator<Term> iter = terms.iterator();
        Term term = iter.next();

        super.cal = term.calculate();

        if (iter.hasNext()) {
            Term term1 = iter.next();
            super.cal = addHashMap(super.cal, term1.calculate());

            while (iter.hasNext()) {
                Term term2 = iter.next();
                super.cal = addHashMap(super.cal, term2.calculate());
            }
        }
        return super.cal;
    }
}
