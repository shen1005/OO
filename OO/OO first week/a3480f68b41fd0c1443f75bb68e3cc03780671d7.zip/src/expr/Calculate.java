package expr;

import java.math.BigInteger;
import java.util.HashMap;

public abstract class Calculate {
    public HashMap<Integer, BigInteger> cal;

    public Calculate() {
        this.cal = new HashMap<>();
    }

    abstract HashMap<Integer, BigInteger> calculate();  //用于计算每个项的值, 第一个Integer为次数（最大为8）， 第二个为系数

    public HashMap<Integer, BigInteger> getCal() {
        return cal;
    }

}
