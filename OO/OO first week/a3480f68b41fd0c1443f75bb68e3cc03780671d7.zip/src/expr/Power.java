package expr;

import java.math.BigInteger;
import java.util.HashMap;

public class Power extends Calculate implements Factor {
    private final int pow;
    private final HashMap<Integer, BigInteger> base;

    public Power(HashMap<Integer, BigInteger> base, int pow) {
        this.pow = pow;
        this.base = base;
    }

    public HashMap<Integer, BigInteger> mulHashMap(
            HashMap<Integer, BigInteger> a, HashMap<Integer, BigInteger> b) {
        HashMap<Integer, BigInteger> res = new HashMap<>(9);

        for (int m = 0;m < 9;m++) {
            BigInteger sum = new BigInteger("0");
            for (int i = 0;i <= m;i++) {
                sum = sum.add(a.get(i).multiply(b.get(m - i)));
            }
            res.put(m, sum);
        }

        return res;
    }

    @Override
    public HashMap<Integer, BigInteger> calculate() {
        super.cal = this.base;

        if (this.pow == 0) {
            BigInteger bigInteger = new BigInteger("1");
            BigInteger bigIntegerZero = new BigInteger("0");
            super.cal.replace(0, bigInteger);
            for (int i = 1;i <= 8;i++) {
                super.cal.replace(i, bigIntegerZero);
            }
        }
        else {
            for (int i = 1;i < this.pow;i++) {
                super.cal = mulHashMap(base, super.cal);
            }
        }
        return super.cal;
    }
}
