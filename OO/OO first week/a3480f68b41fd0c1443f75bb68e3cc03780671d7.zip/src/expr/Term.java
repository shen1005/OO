package expr;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class Term extends Calculate {     //expr: 表达式, term: 项， factor: 因子
    private final HashSet<Factor> factors;

    public Term() {
        super();
        this.factors = new HashSet<>();
    }

    public void addFactor(Factor factor) {
        this.factors.add(factor);
    }

    public HashMap<Integer, BigInteger> mulHashMap(
            HashMap<Integer, BigInteger> a, HashMap<Integer, BigInteger> b) {
        HashMap<Integer, BigInteger> res = new HashMap<>(9);

        for (int m = 0;m < 9;m++) {
            BigInteger sum = new BigInteger("0");
            for (int i = 0;i <= m;i++) {
                sum = sum.add(a.get(i).multiply(b.get(m - i)));
            }
            res.put(m, sum);
        }

        return res;
    }

    @Override
    public HashMap<Integer, BigInteger> calculate() {      //实现乘法, assert此时无前导零（已在因子处全部消除）
        Iterator<Factor> iter = factors.iterator();
        Factor factor = iter.next();

        HashMap<Integer, BigInteger> hashMap;

        if (factor instanceof Power) {
            hashMap = ((Power) factor).calculate();
        }
        else if (factor instanceof Expr) {
            hashMap = ((Expr) factor).calculate();
        }
        else {
            hashMap = ((Number) factor).calculate();
        }

        if (iter.hasNext()) {
            Factor factor1 = iter.next();
            if (factor1 instanceof Power) {
                hashMap = mulHashMap(((Power) factor1).calculate(), hashMap);
            }
            else if (factor1 instanceof Expr) {
                hashMap = mulHashMap(((Expr) factor1).calculate(), hashMap);
            }
            else {
                hashMap = mulHashMap(((Number) factor1).calculate(), hashMap);
            }


            while (iter.hasNext()) {
                Factor factor2 = iter.next();
                if (factor2 instanceof Power) {
                    hashMap = mulHashMap(((Power) factor2).calculate(), hashMap);
                }
                else if (factor2 instanceof Expr) {
                    hashMap = mulHashMap(((Expr) factor2).calculate(), hashMap);
                }
                else {
                    hashMap = mulHashMap(((Number) factor2).calculate(), hashMap);
                }
            }
        }
        return hashMap;
    }
}
