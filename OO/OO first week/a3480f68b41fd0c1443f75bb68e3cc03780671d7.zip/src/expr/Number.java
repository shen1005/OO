package expr;

import java.math.BigInteger;
import java.util.HashMap;

public class Number extends Calculate implements Factor  {

    public Number(BigInteger num) {

        BigInteger b1 = new BigInteger("0");
        BigInteger b2 = new BigInteger("0");
        BigInteger b3 = new BigInteger("0");
        BigInteger b4 = new BigInteger("0");
        BigInteger b5 = new BigInteger("0");
        BigInteger b6 = new BigInteger("0");
        BigInteger b7 = new BigInteger("0");
        BigInteger b8 = new BigInteger("0");

        super.cal = new HashMap<Integer, BigInteger>() {
            {
                put(0, num);
                put(1, b1);
                put(2, b2);
                put(3, b3);
                put(4, b4);
                put(5, b5);
                put(6, b6);
                put(7, b7);
                put(8, b8);
            }
        };
    }

    @Override
    public HashMap<Integer, BigInteger> calculate() {
        return super.getCal();
    }
}
