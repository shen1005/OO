import expr.Expr;
import expr.Power;
import expr.Term;
import expr.Factor;
import expr.Number;

import java.math.BigInteger;
import java.util.HashMap;

public class Parser {
    private final Lexer lexer;

    public Parser(Lexer lexer) {
        this.lexer = lexer;
    }

    public Expr parseExpr() {
        Expr expr = new Expr();

        if (lexer.peek().equals("+")) {
            lexer.next();
            expr.addTerm(parseTerm(1));
        }
        else if (lexer.peek().equals("-")) {
            lexer.next();
            expr.addTerm(parseTerm(-1));
        }
        else {
            expr.addTerm(parseTerm(1)); //parseTerm 后 "pos" 已经指向符号，不需要再下移
            //lexer.next();
        }
        while (lexer.peek().equals("+") || lexer.peek().equals("-")) {
            if (lexer.peek().equals("+")) {
                lexer.next();
                expr.addTerm(parseTerm(1));
            }
            else {
                lexer.next();
                expr.addTerm(parseTerm(-1));
            }
        }

        return expr;
    }

    public Term parseTerm(int exprOp) {
        Term term = new Term();

        if (lexer.peek().equals("+")) {
            lexer.next();
            term.addFactor(parseFactor(exprOp, 1));
        }
        else if (lexer.peek().equals("-")) {
            lexer.next();
            term.addFactor(parseFactor(exprOp, -1));
        }
        else {
            term.addFactor(parseFactor(exprOp, 1));
        }
        while (lexer.peek().equals("*")) {
            lexer.next();
            int termOp = 1;
            if (lexer.peek().equals("-") || lexer.peek().equals("+")) {
                if (lexer.peek().equals("-")) {
                    termOp = -1;
                }
                lexer.next();
            }
            term.addFactor(parseFactor(1, termOp));
        }
        return term;
    }

    public Factor parseFactor(int exprOp, int termOp) {
        if (lexer.peek().equals("(")) {         //表达式因子
            lexer.next();
            Expr expr = parseExpr();            //到')'停止
            lexer.next();                       //'^'
            if (!lexer.peek().equals("^")) {
                return new Power(getBase(expr, exprOp, termOp), 1);
            }
            lexer.next();                       //pow | '+'
            if (lexer.peek().equals("+")) {
                lexer.next();
            }
            int pow = Integer.parseInt(lexer.peek());
            lexer.next();                       //下一个符号
            return new Power(getBase(expr, exprOp, termOp), pow);
        }
        else if (lexer.peek().equals("x")) {    //变量因子: 表达式因子幂次为1的特殊情况
            lexer.next();                       //'^'
            if (!lexer.peek().equals("^")) {
                return new Power(getVar(1, exprOp, termOp), 1);
            }
            lexer.next();                       //pow | '+'
            if (lexer.peek().equals("+")) {
                lexer.next();
            }
            int pow = Integer.parseInt(lexer.peek());
            lexer.next();                       //下一个符号
            return new Power(getVar(pow, exprOp, termOp), 1);
        }
        else {                                  //常数因子
            int facterOp = 1;
            if (lexer.peek().equals("-") || lexer.peek().equals("+")) {
                if (lexer.peek().equals("-")) {
                    facterOp = -1;
                }
                lexer.next();
            }
            BigInteger num = new BigInteger(lexer.peek());
            lexer.next();
            if (exprOp * termOp * facterOp == 1) {
                return new Number(num);
            }
            else {
                return new Number(num.negate());
            }
        }
    }

    public HashMap<Integer, BigInteger> getBase(Expr expr, int exprOp, int termOp) {
        HashMap<Integer, BigInteger> hashMap = expr.calculate();

        if (exprOp * termOp == -1) {
            for (int i = 0;i < 9;i++) {
                hashMap.replace(i, hashMap.get(i).negate());
            }
        }

        return hashMap;
    }

    public HashMap<Integer, BigInteger> getVar(int pow, int exprOp, int termOp) {
        HashMap<Integer, BigInteger> hashMap;

        BigInteger b0 = new BigInteger("0");
        BigInteger b1 = new BigInteger("0");
        BigInteger b2 = new BigInteger("0");
        BigInteger b3 = new BigInteger("0");
        BigInteger b4 = new BigInteger("0");
        BigInteger b5 = new BigInteger("0");
        BigInteger b6 = new BigInteger("0");
        BigInteger b7 = new BigInteger("0");
        BigInteger b8 = new BigInteger("0");

        BigInteger a0 = new BigInteger("1");
        BigInteger a1 = new BigInteger("-1");

        hashMap = new HashMap<Integer, BigInteger>() {
            {
                put(0, b0);
                put(1, b1);
                put(2, b2);
                put(3, b3);
                put(4, b4);
                put(5, b5);
                put(6, b6);
                put(7, b7);
                put(8, b8);
            }
        };

        if (exprOp * termOp == 1) {
            hashMap.replace(pow, a0);
        }
        else {
            hashMap.replace(pow, a1);
        }

        return hashMap;
    }
}
