import com.oocourse.spec1.ExprInput;
import com.oocourse.spec1.ExprInputMode;
import expr.Expr;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainClass {
    public static void main(String[] args) {
        ExprInput scanner = new ExprInput(ExprInputMode.NormalMode);
        String input = scanner.readLine();

        Pattern pattern1 = Pattern.compile("[ |\t]");           //删出input中“ ”和“\t”
        Matcher matcher1 = pattern1.matcher(input);
        String input1 = matcher1.replaceAll("");

        Pattern pattern2 = Pattern.compile("[*]{2}");           //用“^”代替“**”，以减少代码复杂度
        Matcher matcher2 = pattern2.matcher(input1);
        String input2 = matcher2.replaceAll("^");

        Lexer lexer = new Lexer(input2);
        Parser parser = new Parser(lexer);

        Expr expr = parser.parseExpr();
        expr.calculate();

        printAnswer(expr);
        checkZero(expr);

    }

    public static void checkZero(Expr expr) {
        boolean isZero = true;
        BigInteger zero = new BigInteger("0");

        for (int i = 0;i <= 8;i++) {
            if (!expr.cal.get(i).equals(zero)) {
                isZero = false;
            }
        }
        if (isZero) {
            System.out.print("0");
        }
    }

    public static void printAnswer(Expr expr) {
        BigInteger zero = new BigInteger("0");
        BigInteger one = new BigInteger("1");
        for (int i = 8;i >= 0;i--) {
            if (i == 0) {
                if (!expr.cal.get(i).equals(zero)) {
                    if (expr.cal.get(i).toString().charAt(0) != '-') {
                        System.out.print("+");
                    }
                    System.out.printf("%s", expr.cal.get(i).toString());
                }
            }
            else if (i == 1) {
                if (!expr.cal.get(i).equals(zero)) {
                    if (expr.cal.get(i).equals(one)) {
                        if (expr.cal.get(i).toString().charAt(0) != '-') {
                            System.out.print("+");
                        }
                        System.out.print("x");
                    }
                    else {
                        if (expr.cal.get(i).toString().charAt(0) != '-') {
                            System.out.print("+");
                        }
                        System.out.printf("%s*x", expr.cal.get(i).toString());
                    }
                }
            }
            else {
                if (!expr.cal.get(i).equals(zero)) {
                    if (expr.cal.get(i).equals(one)) {
                        if (expr.cal.get(i).toString().charAt(0) != '-') {
                            System.out.print("+");
                        }
                        System.out.printf("x**%d", i);
                    }
                    else {
                        if (expr.cal.get(i).toString().charAt(0) != '-') {
                            System.out.print("+");
                        }
                        System.out.printf("%s*x**%d", expr.cal.get(i).toString(), i);
                    }
                }
            }
        }
    }
}
